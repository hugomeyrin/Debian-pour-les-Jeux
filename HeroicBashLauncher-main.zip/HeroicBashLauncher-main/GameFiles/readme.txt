All the games' launch files will be saved in this folder

-----------------------------------------------------------------------------
Each launch file will be named after the game and will contain the following:
    - Game's Full Name 
    - Games's App Name
    - Launch command to update parameters
    - Launch command for both online/offline
    
-----------------------------------------------------------------------------
For newly installed games, run the HeroicBashLauncher executable again to 
create corresponding launch scripts

-----------------------------------------------------------------------------
NOTE - Don't try to move or rename the launch scripts
