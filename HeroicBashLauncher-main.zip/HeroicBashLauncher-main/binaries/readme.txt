-----------------------------------------------------------------------------
NOTE FOR STEAM DECK AND APPIMAGE USERS

This folder has been created particularly for the above mentioned users.

Bash Launcher will automactically use the legendary and gogdl binaries
stored in this folder and thus, users DON'T need to specify alternative
binaries in the Heroic app anymore unless they have some reason.

-----------------------------------------------------------------------------
WHY?

This is because a temporary folder that includes both these binaries gets
created only when the the AppImage is running. This folder is needed by Bash 
Launcher to create and run a game's launch script and thus requires 
users to keep Heroic open all the time, making it inconvenient.
    
-----------------------------------------------------------------------------